add_hours = function(x,y){
  return ((x + y) %% 12)
}
random_hour = function(n){
  return( round(abs(stats::rnorm(n,0,12))) %% 12)
}




# force error rnorm(n,0,12) instead of stats::rnorm(n,0,12) 