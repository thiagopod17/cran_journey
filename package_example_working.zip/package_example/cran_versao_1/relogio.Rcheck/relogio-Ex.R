pkgname <- "relogio"
source(file.path(R.home("share"), "R", "examples-header.R"))
options(warn = 1)
library('relogio')

base::assign(".oldSearch", base::search(), pos = 'CheckExEnv')
base::assign(".old_wd", base::getwd(), pos = 'CheckExEnv')
cleanEx()
nameEx("add_hours")
### * add_hours

flush(stderr()); flush(stdout())

### Name: add_hours
### Title: This functions add two hours and return another valid hour
### Aliases: add_hours

### ** Examples

# It is 11AM and my the application form for NASA is going to open in 27 hours. 
add_hours(11,27)



cleanEx()
nameEx("relogio-package")
### * relogio-package

flush(stderr()); flush(stdout())

### Name: relogio-package
### Title: Algebra de horas
### Aliases: relogio-package relogio
### Keywords: package magic

### ** Examples

# Try to add an example showing the full capability of the package

going_to_est = random_hour(1)
going_home = going_to_est + random_hour(1)
print(paste("I came at:", going_to_est, "and went home at:", going_home))




### * <FOOTER>
###
cleanEx()
options(digits = 7L)
base::cat("Time elapsed: ", proc.time() - base::get("ptime", pos = 'CheckExEnv'),"\n")
grDevices::dev.off()
###
### Local variables: ***
### mode: outline-minor ***
### outline-regexp: "\\(> \\)?### [*]+" ***
### End: ***
quit('no')
